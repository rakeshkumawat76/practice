module JdbcDemo {
	requires java.sql;
}